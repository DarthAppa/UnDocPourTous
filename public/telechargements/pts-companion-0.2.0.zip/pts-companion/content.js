// PTS Companion : lecture seule sur packtasmall.fr.
// DONNÉES RÉCUPÉRÉES : UNIQUEMENT la collection (/draft) et les replays des combats (/profil, /tournoi).
// Rien d'autre : ni pièces, ni boutique, ni messages, ni autres pages. /profil et /tournoi ne servent
// qu'à repérer les identifiants des combats ; leur contenu n'est pas envoyé.
//
// Rythme (v0.2) :
// - Collection : à l'ouverture du site, puis au changement de page (sortie des packs, de la boutique…),
//   au retour sur l'onglet et après un échange, au plus une fois par minute. Si l'empreinte n'a pas
//   bougé, rien n'est envoyé ; sinon seules les cartes ajoutées ou retirées partent (calcul dans le service worker).
// - Replays : à l'ouverture, puis toutes les 3 min tant que l'onglet est visible, et 3 min après un
//   événement de combat. Seuls les combats jamais vus sont téléchargés.
// Ne clique jamais, ne lance aucun combat, n'envoie rien au site à part des lectures.

(() => {
  const SLEEP = ms => new Promise(r => setTimeout(r, ms));
  const UUID = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g;
  const send = m => chrome.runtime.sendMessage(m);
  const visible = () => document.visibilityState === 'visible';

  let conf = null;
  let joueur = null;              // { id, username } du compte PTS ouvert
  let derniereCollection = 0, derniersReplays = 0, cycle = 0;
  let occupeCol = false, occupeRep = false;

  // Extrait la valeur JSON qui suit "key": dans un flux RSC (tableau ou objet), en respectant les chaînes
  function valueAt(text, start) {
    let d = 0, inS = false, j = start;
    for (; j < text.length; j++) {
      const c = text[j];
      if (inS) { if (c === '\\') { j++; continue; } if (c === '"') inS = false; continue; }
      if (c === '"') inS = true;
      else if (c === '[' || c === '{') d++;
      else if (c === ']' || c === '}') { d--; if (d === 0) break; }
    }
    return text.slice(start, j + 1);
  }
  function grab(text, key) {
    const i = text.indexOf('"' + key + '":');
    if (i < 0) return null;
    try { return JSON.parse(valueAt(text, text.indexOf(':', i) + 1)); } catch { return null; }
  }

  async function readCollection() {
    const t = await fetch('/draft', { headers: { RSC: '1' }, credentials: 'include', cache: 'no-store' }).then(r => r.text());
    const playerId = (t.match(/"playerId":"(\d{5,25})"/) || [])[1];
    const username = (t.match(/"username":"([^"]{1,64})"/) || [])[1] || null;
    const roster = grab(t, 'roster');
    if (!playerId || !Array.isArray(roster)) return null;
    // Détails par carte : l'objet "meta" qui contient l'id de la première carte
    let meta = null;
    for (const m of t.matchAll(/"meta":\{/g)) {
      const raw = valueAt(t, m.index + 7);
      if (roster[0] && raw.includes('"' + roster[0].id + '":')) { try { meta = JSON.parse(raw); } catch {} break; }
    }
    const clean = roster.map(c => { const o = { ...c }; if (typeof o.fill === 'string') delete o.fill; return o; });
    return { playerId, username, roster: clean, meta };
  }

  async function listMatchIds(avecTournoi) {
    const ids = new Set();
    for (const path of avecTournoi ? ['/profil', '/tournoi'] : ['/profil']) {
      try {
        const h = await fetch(path, { credentials: 'include', cache: 'no-store' }).then(r => r.text());
        (h.match(UUID) || []).forEach(x => ids.add(x));
      } catch {}
    }
    return [...ids];
  }

  async function readReplay(id, action) {
    const r = await fetch('/fight?match=' + id, {
      method: 'POST', credentials: 'include',
      headers: { 'Next-Action': action, 'Content-Type': 'text/plain;charset=UTF-8', Accept: 'text/x-component' },
      body: JSON.stringify([id])
    });
    const t = await r.text();
    const line = t.split('\n').find(l => l.startsWith('1:'));
    if (!line) return { error: 'action_changed' };
    let j; try { j = JSON.parse(line.slice(2)); } catch { return { error: 'action_changed' }; }
    if (!j.ok) return { error: j.reason || 'not_ok' };
    if (!j.output || !j.output.details) return { error: 'unexpected' };
    // Version allégée : on retire les portraits, l'animation et le fil de texte
    const out = { ...j.output }; delete out.snapshots; delete out.feed;
    const slim = { ...j, output: out }; delete slim.portraits; delete slim.cards; delete slim.youBanner; delete slim.opponentBanner;
    return { replay: slim };
  }

  const rapporter = partiel => send({ type: 'report', report: { ...partiel, at: Date.now() } }).catch(() => {});

  // ---------- Collection : empreinte, puis delta ----------
  async function verifierCollection(raison, force = false) {
    const ecart = (conf.collection_min_gap_seconds || 60) * 1000;
    if (occupeCol || (!force && Date.now() - derniereCollection < ecart)) return null;
    if (!(await send({ type: 'logged' }).catch(() => false))) return null;   // extension non connectée : aucune lecture
    occupeCol = true; derniereCollection = Date.now();
    try {
      const col = await readCollection();
      if (!col) { await rapporter({ reason: raison, error: 'not_logged_in_pts' }); return null; }
      joueur = { id: col.playerId, username: col.username };
      const res = await send({ type: 'push_collection', col });
      await rapporter({ reason: raison, player: joueur, collection: res });
      return res;
    } catch (e) {
      await rapporter({ reason: raison, error: String(e && e.message || e) });
      return null;
    } finally { occupeCol = false; }
  }

  // ---------- Replays : uniquement les nouveaux ----------
  async function verifierReplays(raison) {
    if (occupeRep) return;
    if (!joueur) await verifierCollection(raison, true);
    if (!joueur) return;
    if (!(await send({ type: 'logged' }).catch(() => false))) return;
    occupeRep = true; derniersReplays = Date.now();
    const rapport = { reason: raison, player: joueur, found: 0, sent: 0, attached: 0, errors: [] };
    try {
      const avecTournoi = cycle++ % (conf.tournoi_every || 5) === 0;
      const ids = await listMatchIds(avecTournoi);
      // Le service worker retire les combats déjà traités et rattache ceux déjà en base sans les télécharger
      const todo = await send({ type: 'filter_new', playerId: joueur.id, ids });
      rapport.found = ids.length;
      rapport.attached = (todo && todo.attached) || 0;
      if (todo && todo.error) rapport.errors.push(todo.error);
      for (const id of (todo && todo.ids) || []) {
        const res = await readReplay(id, todo.action);
        if (res.error) {
          if (res.error !== 'not_found') rapport.errors.push(res.error);
          await send({ type: 'mark_seen', playerId: joueur.id, id, failed: res.error });
          if (res.error === 'action_changed') break;
        } else {
          const ok = await send({ type: 'push_replay', playerId: joueur.id, id, replay: res.replay });
          if (ok && !ok.error) rapport.sent++; else rapport.errors.push((ok && ok.error) || 'push_failed');
        }
        await SLEEP(1500); // reste discret avec le serveur du jeu
      }
    } catch (e) {
      rapport.errors.push(String(e && e.message || e));
    } finally {
      occupeRep = false;
      await rapporter(rapport);
    }
  }

  // ---------- Déclencheurs ----------
  function demarrer() {
    const periode = (conf.replay_check_seconds || 180) * 1000;

    // Toutes les 3 min, seulement si l'onglet est visible
    setInterval(() => { if (visible()) verifierReplays('minuterie'); }, periode);

    // Retour sur l'onglet : rattrapage si la dernière vérification est ancienne
    document.addEventListener('visibilitychange', () => {
      if (!visible()) return;
      verifierCollection('retour');
      if (Date.now() - derniersReplays >= periode) verifierReplays('retour');
    });

    // Changement de page dans le site (sortie des packs, de la boutique, des échanges…)
    let chemin = location.pathname;
    setInterval(() => {
      if (location.pathname !== chemin) { chemin = location.pathname; verifierCollection('navigation'); }
    }, 2000);

    if (conf.use_events) ecouterEvenements();
  }

  // Flux d'événements interne du site : on n'utilise que le NOM des événements de combat et d'échange.
  // Les événements de chat (social, global-chat, fight-chat) ne sont jamais écoutés.
  function ecouterEvenements() {
    let source = null, attenteReplay = null;
    const delai = (conf.event_delay_seconds || 180) * 1000;
    const ouvrir = () => {
      if (source || !visible() || typeof EventSource === 'undefined') return;
      source = new EventSource('/api/events');
      for (const ev of ['queue', 'challenge', 'forfeit']) {
        source.addEventListener(ev, () => {
          clearTimeout(attenteReplay);
          attenteReplay = setTimeout(() => verifierReplays('evenement_' + ev), ev === 'forfeit' ? 5000 : delai);
        });
      }
      source.addEventListener('trade', () => setTimeout(() => verifierCollection('echange', true), 5000));
      source.onerror = () => { if (source && source.readyState === EventSource.CLOSED) { source = null; setTimeout(ouvrir, 60000); } };
    };
    const fermer = () => { if (source) { source.close(); source = null; } };
    document.addEventListener('visibilitychange', () => (visible() ? ouvrir() : fermer()));
    ouvrir();
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg && msg.type === 'sync') {
      (async () => { await verifierCollection('manuel', true); await verifierReplays('manuel'); return { ok: true }; })().then(reply);
      return true;
    }
  });

  // Première vérification à chaque ouverture du site (= connexion au site PTS)
  setTimeout(async () => {
    conf = await send({ type: 'get_config' }).catch(() => null) || {};
    await verifierCollection('ouverture', true);
    await verifierReplays('ouverture');
    demarrer();
  }, 4000);
})();
