// PTS Companion : calcul de l'empreinte et des changements de collection.
// Partagé entre le service worker (importScripts) et les tests Node (require).
// Une carte peut exister en plusieurs exemplaires avec le même id : on compare donc par groupe d'id.
(function (root) {
  // Forme canonique : cartes triées par id, puis par contenu ; clés d'objet triées
  function canon(v) {
    if (Array.isArray(v)) return v.map(canon);
    if (v && typeof v === 'object') return Object.keys(v).sort().reduce((o, k) => (o[k] = canon(v[k]), o), {});
    return v;
  }
  const str = v => JSON.stringify(canon(v));

  function groupes(roster) {
    const g = {};
    for (const c of roster) (g[String(c.id)] ||= []).push(str(c));
    for (const id in g) g[id].sort();
    return g;
  }

  // Texte stable à hacher : même collection = même texte, quel que soit l'ordre renvoyé par le site
  function texteEmpreinte(roster, meta) {
    const g = groupes(roster);
    return Object.keys(g).sort().map(id => id + '=' + g[id].join('|')).join('\n') + '\n#' + str(meta || {});
  }

  // Changements entre l'ancienne et la nouvelle collection
  // upsert : toutes les cartes des groupes nouveaux ou modifiés ; remove : ids des groupes disparus ou modifiés
  function delta(ancien, nouveau) {
    const a = groupes(ancien.roster), n = groupes(nouveau.roster);
    const upsertIds = Object.keys(n).filter(id => !a[id] || a[id].join('|') !== n[id].join('|'));
    const goneIds = Object.keys(a).filter(id => !n[id]);
    const set = new Set(upsertIds);
    const upsert = nouveau.roster.filter(c => set.has(String(c.id)));
    const remove = [...new Set([...goneIds, ...upsertIds.filter(id => a[id])])];
    const am = ancien.meta || {}, nm = nouveau.meta || {};
    const metaUpsert = {};
    for (const k of Object.keys(nm)) if (!(k in am) || str(am[k]) !== str(nm[k])) metaUpsert[k] = nm[k];
    const metaRemove = Object.keys(am).filter(k => !(k in nm));
    return {
      upsert, remove, metaUpsert, metaRemove,
      ajoutees: upsertIds.filter(id => !a[id]), retirees: goneIds,
      vide: !upsert.length && !remove.length && !Object.keys(metaUpsert).length && !metaRemove.length
    };
  }

  // Applique un delta (même règle que la fonction SQL push_collection_delta)
  function appliquer(ancien, d) {
    const out = new Set([...d.remove, ...d.upsert.map(c => String(c.id))]);
    const roster = ancien.roster.filter(c => !out.has(String(c.id))).concat(d.upsert);
    const meta = { ...(ancien.meta || {}) };
    for (const k of d.metaRemove) delete meta[k];
    Object.assign(meta, d.metaUpsert);
    return { roster, meta };
  }

  const api = { texteEmpreinte, delta, appliquer };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PTS_DELTA = api;
})(typeof self !== 'undefined' ? self : this);
