// PTS Companion : service worker. Gère la connexion Discord (via Supabase) et l'envoi des données.
// v0.2 : collection envoyée en delta (cartes ajoutées / retirées), replays filtrés avant téléchargement.
importScripts('config.js', 'delta.js');
const C = self.PTS_CONFIG;
const D = self.PTS_DELTA;

// ---------- Session ----------
async function getSession() { return (await chrome.storage.local.get('session')).session || null; }
async function setSession(s) { await chrome.storage.local.set({ session: s }); }

async function login() {
  const redirect = chrome.identity.getRedirectURL('supabase');
  const url = `${C.SUPABASE_URL}/auth/v1/authorize?provider=discord&redirect_to=${encodeURIComponent(redirect)}`;
  const back = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
  const p = new URLSearchParams(new URL(back).hash.slice(1));
  if (!p.get('access_token')) throw new Error(p.get('error_description') || 'login_failed');
  const s = { access_token: p.get('access_token'), refresh_token: p.get('refresh_token'),
              expires_at: Date.now() + Number(p.get('expires_in') || 3600) * 1000 };
  s.user = await fetch(`${C.SUPABASE_URL}/auth/v1/user`, { headers: { apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + s.access_token } }).then(r => r.json());
  await setSession(s);
  return s;
}

async function token() {
  let s = await getSession();
  if (!s) return null;
  if (Date.now() > s.expires_at - 60000) {
    const r = await fetch(`${C.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST', headers: { apikey: C.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: s.refresh_token })
    });
    if (!r.ok) { await setSession(null); return null; }
    const j = await r.json();
    s = { ...s, access_token: j.access_token, refresh_token: j.refresh_token, expires_at: Date.now() + j.expires_in * 1000 };
    await setSession(s);
  }
  return s.access_token;
}

async function rpc(fn, args) {
  const t = await token();
  if (!t) return { error: 'not_logged_in' };
  const r = await fetch(`${C.SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: { apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + t, 'Content-Type': 'application/json' },
    body: JSON.stringify(args)
  });
  const body = await r.text();
  if (!r.ok) { try { return { error: JSON.parse(body).message }; } catch { return { error: 'http_' + r.status }; } }
  try { return { data: JSON.parse(body) }; } catch { return { data: body }; }
}

async function sha256(s) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}

// ---------- Réglages distants (identifiant technique du site, rythmes) ----------
async function remoteConfig() {
  const cache = (await chrome.storage.local.get('rconf')).rconf;
  if (cache && cache.v === 2 && Date.now() - cache.at < 30 * 60000) return cache;
  const base = {
    v: 2, at: Date.now(), action: C.FIGHT_ACTION,
    replay_check_seconds: C.REPLAY_CHECK_SECONDS, tournoi_every: C.TOURNOI_EVERY,
    collection_min_gap_seconds: C.COLLECTION_MIN_GAP_SECONDS, use_events: C.USE_EVENTS,
    event_delay_seconds: C.EVENT_DELAY_SECONDS
  };
  try {
    const rows = await fetch(`${C.SUPABASE_URL}/rest/v1/config?select=key,value`, { headers: { apikey: C.SUPABASE_ANON_KEY } }).then(r => r.json());
    const m = Object.fromEntries(rows.map(r => [r.key, r.value]));
    const conf = { ...base, action: m.fight_action || base.action };
    for (const k of ['replay_check_seconds', 'tournoi_every', 'collection_min_gap_seconds', 'event_delay_seconds']) {
      const n = Number(m[k]); if (n > 0) conf[k] = n;
    }
    if (typeof m.use_events === 'boolean') conf.use_events = m.use_events;
    // Garde-fous : jamais plus d'une vérification de replays par minute
    conf.replay_check_seconds = Math.max(60, conf.replay_check_seconds);
    conf.collection_min_gap_seconds = Math.max(30, conf.collection_min_gap_seconds);
    await chrome.storage.local.set({ rconf: conf });
    return conf;
  } catch { return base; }
}

// ---------- Combats déjà traités (par compte PTS) ----------
async function seen(playerId) { return new Set(((await chrome.storage.local.get('seen_' + playerId))['seen_' + playerId]) || []); }
async function addSeen(playerId, ids) {
  const s = await seen(playerId); for (const id of [].concat(ids)) s.add(id);
  await chrome.storage.local.set({ ['seen_' + playerId]: [...s].slice(-1000) });
}

// ---------- Collection : empreinte + delta ----------
async function pushCollection(col) {
  const pid = col.playerId;
  // Rattachement du compte (et mise à jour de last_sync) au plus une fois par heure
  const lk = 'linked_' + pid;
  const linkedAt = (await chrome.storage.local.get(lk))[lk] || 0;
  if (Date.now() - linkedAt > 3600e3) {
    const link = await rpc('link_account', { p_player_id: pid, p_username: col.username || '' });
    if (link.error) return link;
    if (link.data === 'owned_by_other') return { error: 'compte_deja_rattache_a_quelqu_un_d_autre' };
    await chrome.storage.local.set({ [lk]: Date.now() });
  }

  const hash = await sha256(D.texteEmpreinte(col.roster, col.meta));
  const sk = 'col_' + pid;
  const snap = (await chrome.storage.local.get(sk))[sk];

  const accounts = (await chrome.storage.local.get('accounts')).accounts || {};
  accounts[pid] = { username: col.username, at: Date.now(), cards: col.roster.length };
  await chrome.storage.local.set({ accounts });

  // Même empreinte : rien n'a bougé, rien n'est envoyé
  if (snap && snap.hash === hash) return { status: 'unchanged', cards: col.roster.length };

  const garder = () => chrome.storage.local.set({ [sk]: { hash, roster: col.roster, meta: col.meta || {} } });

  // Collection connue : on n'envoie que les cartes ajoutées / retirées
  if (snap) {
    const d = D.delta(snap, col);
    const res = await rpc('push_collection_delta', {
      p_player_id: pid, p_base_hash: snap.hash, p_new_hash: hash,
      p_upsert: d.upsert, p_remove: d.remove, p_meta_upsert: d.metaUpsert, p_meta_remove: d.metaRemove
    });
    if (res.error) return res;
    if (res.data !== 'need_full') {
      await garder();
      return { status: 'delta', added: d.ajoutees.length, removed: d.retirees.length, cards: col.roster.length };
    }
  }

  // Première fois (ou base désynchronisée) : collection complète
  const res = await rpc('push_collection', { p_player_id: pid, p_roster: col.roster, p_meta: col.meta, p_hash: hash });
  if (res.error) return res;
  await garder();
  return { status: res.data === 'unchanged' ? 'unchanged' : 'full', cards: col.roster.length };
}

// ---------- Replays : filtrage des doublons avant téléchargement ----------
async function filterNew(playerId, ids) {
  const conf = await remoteConfig();
  const done = await seen(playerId);
  let rest = [...new Set(ids)].filter(x => !done.has(x));
  let attached = 0;
  if (rest.length) {
    // Combats déjà en base (envoyés par l'adversaire, par exemple) : rattachés sans téléchargement
    const known = await rpc('known_matches', { p_ids: rest });
    if (known.error) return { ids: [], action: conf.action, error: known.error };
    const deja = new Set((known.data || []).map(x => (typeof x === 'string' ? x : x.known_matches || x.match_id)));
    for (const id of deja) {
      const r = await rpc('attach_known_replay', { p_player_id: playerId, p_match_id: id });
      if (!r.error) attached++;
    }
    if (deja.size) await addSeen(playerId, [...deja]);
    rest = rest.filter(x => !deja.has(x));
  }
  return { ids: rest, action: conf.action, attached };
}

// ---------- Messages du script de page et du popup ----------
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    switch (msg.type) {
      case 'login': try { const s = await login(); return { user: s.user }; } catch (e) { return { error: String(e.message || e) }; }
      case 'logout': await setSession(null); return { ok: true };
      case 'logged': return !!(await getSession());
      case 'get_config': return await remoteConfig();
      case 'status': {
        const s = await getSession();
        const { lastReport, accounts } = await chrome.storage.local.get(['lastReport', 'accounts']);
        return { user: s && s.user, lastReport, accounts: accounts || {} };
      }
      case 'push_collection': return await pushCollection(msg.col);
      case 'filter_new': return await filterNew(msg.playerId, msg.ids);
      case 'push_replay': {
        const res = await rpc('push_replay', { p_player_id: msg.playerId, p_match_id: msg.id, p_payload: msg.replay });
        if (!res.error) await addSeen(msg.playerId, msg.id);
        return res;
      }
      case 'mark_seen': if (msg.failed === 'not_found') await addSeen(msg.playerId, msg.id); return { ok: true };
      case 'report': {
        // On garde les dernières infos de collection et de replays, même si elles viennent de vérifications séparées
        const prev = (await chrome.storage.local.get('lastReport')).lastReport || {};
        const r = msg.report;
        const next = { ...prev, at: r.at, reason: r.reason, player: r.player || prev.player, error: r.error || null };
        if (r.collection) next.collection = { ...r.collection, at: r.at };
        if ('found' in r) next.replays = { found: r.found, sent: r.sent, attached: r.attached, errors: r.errors, at: r.at };
        await chrome.storage.local.set({ lastReport: next });
        return { ok: true };
      }
      case 'sync_now': return await syncTabs();
      case 'delete_all': {
        const r = await rpc('delete_my_data', {});
        if (!r.error) {
          const all = await chrome.storage.local.get(null);
          await chrome.storage.local.remove(Object.keys(all).filter(k => /^(seen_|col_|linked_)/.test(k) || k === 'accounts' || k === 'lastReport'));
        }
        return r;
      }
    }
  })().then(reply);
  return true;
});

// ---------- Synchro manuelle (bouton du popup) ----------
async function syncTabs() {
  if (!(await getSession())) return { error: 'not_logged_in' };
  const tabs = await chrome.tabs.query({ url: ['https://www.packtasmall.fr/*', 'https://packtasmall.fr/*'] });
  if (!tabs.length) return { error: 'aucun_onglet_pts' };
  try { return await chrome.tabs.sendMessage(tabs[0].id, { type: 'sync' }); } catch (e) { return { error: 'recharger_la_page_pts' }; }
}
