const $ = id => document.getElementById(id);
const send = m => chrome.runtime.sendMessage(m);
const ago = t => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? "à l'instant" : m < 60 ? `il y a ${m} min` : `il y a ${Math.round(m / 60)} h`; };
const ERR = {
  not_logged_in_pts: "Tu n'es pas connecté sur packtasmall.fr.",
  aucun_onglet_pts: 'Ouvre packtasmall.fr dans un onglet.',
  recharger_la_page_pts: "Recharge l'onglet packtasmall.fr.",
  action_changed: "Le site a été mis à jour : la lecture des replays est en pause le temps d'adapter l'extension.",
  compte_deja_rattache_a_quelqu_un_d_autre: "Ce compte PTS est déjà rattaché à un autre utilisateur."
};

async function render() {
  const s = await send({ type: 'status' });
  const logged = !!(s && s.user);
  $('login').hidden = logged; $('sync').hidden = !logged; $('logout').hidden = !logged; $('delete').hidden = !logged;
  const name = logged && (s.user.user_metadata && (s.user.user_metadata.full_name || s.user.user_metadata.name));
  $('who').innerHTML = logged ? `Connecté : <b>${name || 'Discord'}</b>` : 'Connecte-toi avec Discord pour partager tes données et accéder aux builders.';
  const acc = Object.entries(s.accounts || {});
  $('accounts').hidden = !acc.length;
  $('accounts').innerHTML = '<div class="muted">Comptes PTS rattachés</div>' +
    acc.map(([, a]) => `<div class="row"><span>${a.username || '?'}</span><span class="muted">${a.cards} cartes · ${ago(a.at)}</span></div>`).join('');
  const r = s.lastReport;
  $('last').hidden = !r;
  if (r) {
    const c = r.collection, rp = r.replays;
    const err = r.error || (c && c.error) || (rp && rp.errors && rp.errors[0]);
    const txtCol = !c ? '' : c.status === 'unchanged' ? 'Collection à jour'
      : c.status === 'delta' ? `Collection : +${c.added} / −${c.removed} carte(s) envoyée(s)`
      : 'Collection complète envoyée';
    const txtRep = !rp ? '' : `${rp.sent || 0} nouveau(x) replay(s)` + (rp.attached ? ` · ${rp.attached} déjà en base` : '');
    $('last').innerHTML = `Dernière vérification ${ago(r.at)}${r.player ? ' (' + r.player.username + ')' : ''}<br>` +
      (err ? `<span class="bad">${ERR[err] || err}</span>` : `<span class="ok">${[txtCol, txtRep].filter(Boolean).join(' · ')}</span>`) +
      (c && c.at ? `<br>Collection vérifiée ${ago(c.at)}` : '') + (rp && rp.at ? ` · replays ${ago(rp.at)}` : '');
  }
}

$('login').onclick = async () => { $('who').textContent = 'Ouverture de Discord…'; const r = await send({ type: 'login' }); if (r.error) $('who').textContent = 'Connexion impossible : ' + r.error; render(); };
$('logout').onclick = async () => { await send({ type: 'logout' }); render(); };
$('sync').onclick = async () => { $('sync').textContent = 'Synchro en cours…'; const r = await send({ type: 'sync_now' }); $('sync').textContent = 'Synchroniser maintenant'; if (r && r.error) $('last').hidden = false, $('last').innerHTML = `<span class="bad">${ERR[r.error] || r.error}</span>`; else render(); };
let armed = false;
$('delete').onclick = async () => {
  if (!armed) { armed = true; $('confirm').hidden = false; return; }
  const r = await send({ type: 'delete_all' }); armed = false; $('confirm').hidden = true;
  $('who').textContent = r.error ? 'Suppression impossible : ' + r.error : 'Toutes tes données ont été supprimées.';
};
render();
