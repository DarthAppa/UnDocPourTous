// Réglages du projet. Remplacer les deux valeurs par celles de Supabase › Project Settings › API.
// La clé « anon public » est faite pour être visible : ne jamais mettre la clé service_role ici.
// Les rythmes ci-dessous sont des valeurs de secours : la table `config` de Supabase les remplace.
self.PTS_CONFIG = {
  SUPABASE_URL: 'https://wibfiqtuqfddijjlfscs.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndpYmZpcXR1cWZkZGlqamxmc2NzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE4NTAwNjIsImV4cCI6MjEwNzQyNjA2Mn0.qAzmjV3jlSREIXY7Nrc0-lWMm5h1XK3DM51z6PFiFUc',
  // Valeur de secours si la table config est injoignable
  FIGHT_ACTION: '40fc2b5632a6ac2f7489a2d8f24d90c63ef65c2a4a',

  // Replays : vérification toutes les 3 min (combat le plus long mesuré : 176 s ; écart médian entre deux combats : 5 min),
  // seulement quand l'onglet packtasmall.fr est visible.
  REPLAY_CHECK_SECONDS: 180,
  // /tournoi n'est relu qu'une vérification sur N (les combats classés sont sur /profil)
  TOURNOI_EVERY: 5,
  // Collection : au plus une vérification par minute (ouverture du site, changement de page, échange)
  COLLECTION_MIN_GAP_SECONDS: 60,
  // Utiliser le flux d'événements interne du site (/api/events) comme déclencheur. Seuls les NOMS
  // d'événements sont utilisés (combat, échange) ; les chats ne sont jamais lus.
  USE_EVENTS: true,
  // Délai après un événement de combat avant de chercher le replay
  EVENT_DELAY_SECONDS: 180,

  VERSION: '0.2.0'
};
